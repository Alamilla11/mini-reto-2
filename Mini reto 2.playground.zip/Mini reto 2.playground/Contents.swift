//: Playground - noun: a place where people can play

import UIKit

enum Velocidades : Int{
    case apagado = 0
    case velocidadBaja = 20
    case velocidadMedia = 50
    case velocidadAlta = 120
    init (velocidadInicial : Velocidades){
        self = velocidadInicial
    }
}

class Auto {
    var velocidad : Velocidades
    init (){
        velocidad = Velocidades(velocidadInicial: Velocidades.apagado)
    }
    
    func cambioDeVelocidad () -> (actual : Int, velocidadEnCadena : String){
        var velEnCadena : String = ""
        switch self.velocidad.rawValue {
        case 0:
            self.velocidad = Velocidades.velocidadBaja
            velEnCadena = "Velocidad baja"
        case 20:
            self.velocidad = Velocidades.velocidadMedia
            velEnCadena = "Velocidad media"
        case 50:
            self.velocidad = Velocidades.velocidadAlta
            velEnCadena = "Velocidad alta"
        case 120:
            self.velocidad = Velocidades.velocidadMedia
            velEnCadena = "Velocidad media"
        default:
            self.velocidad = Velocidades.apagado
            velEnCadena = "Apagado"
        }
        
        return (self.velocidad.rawValue, velEnCadena)
    }
}


var auto = Auto()

print("1. \(auto.velocidad.rawValue), Apagado")
for i in 2...21 {
    var miTupla=auto.cambioDeVelocidad()
    print("\(i) \(miTupla.actual), \(miTupla.velocidadEnCadena)")
}  //se imprime del 1 al 21 pero se ejecuta 20 veces



